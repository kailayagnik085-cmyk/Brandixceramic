import phonenumbers
from phonenumbers import geocoder, carrier, timezone

def track_number(number):
    try:
        # નંબરને પાર્સ કરો (દેશના કોડ સાથે હોવો જોઈએ, જેમ કે +91)
        parsed_number = phonenumbers.parse(number)

        # ૧. દેશ/વિસ્તાર (Location)
        location = geocoder.description_for_number(parsed_number, "en")
        
        # ૨. સર્વિસ પ્રોવાઈડર (Operator)
        operator = carrier.name_for_number(parsed_number, "en")
        
        # ૩. ટાઈમઝોન (Timezone)
        time_zone = timezone.time_zones_for_number(parsed_number)

        print(f"\n--- મોબાઈલ વિગતો ---")
        print(f"દેશ/વિસ્તાર: {location if location else 'મળ્યું નથી'}")
        print(f"ઓપરેટર: {operator if operator else 'મળ્યું નથી'}")
        print(f"ટાઈમઝોન: {time_zone}")

    except Exception as e:
        print("ભૂલ: સાચો મોબાઈલ નંબર નાખો (દા.ત. +919876543210)")

# યુઝર પાસેથી ઇનપુટ લેવું
num = input("મોબાઈલ નંબર નાખો (with country code): ")
track_number(num)
